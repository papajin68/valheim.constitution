# Constitution
Some honest labor, and a hearty meal, will improve the constitution of any Viking!  Allows the adjustment of base health and stamina as well as adding a "Constitution" skill which will adjust health and stamina according to the player's constitution level.
  
MUST be installed on both the client and the server!

## Configuration
  
On first launch a config file will be generated in BepInEx/config.
  
## License  
  
This project is licensed under the GNU General Public License v3.0 - see the [LICENSE](https://github.com/papajin68/valheim.constitution/blob/master/LICENSE) file for details  
